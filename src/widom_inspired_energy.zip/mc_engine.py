# src/simulation/mc_engine.py
"""
Monte Carlo engine with proper energy consistency verification
FIXED VERSION: No stored field usage, proper neighborhood wiping
"""

import math
import random
import time
from typing import Dict, List, Tuple, Any, Optional
import numpy as np

from src.utils.energy_utils import (
    wipe_all_energy_fields, clear_all_caches,
    get_k_ring_neighborhood, compute_total_energy_fresh,
    verify_energy_convention
)

class MonteCarloEngine:
    """
    Monte Carlo engine that preserves detailed balance with verified energy consistency
    """
    
    def __init__(self, temperature: float = 0.3, energy_model=None, 
                 flip_engine=None, config: Optional[Dict] = None):
        self.temperature = temperature
        self.energy_model = energy_model
        self.flip_engine = flip_engine
        self.config = config or {}
        
        # Use tested neighborhood radius (default 3, will be verified)
        self.neighborhood_radius = self.config.get("neighborhood_radius", 3)
        
        # Global energy tracking
        self.current_energy = 0.0
        
        # Configurable parameters
        self.base_steps = self.config.get("base_steps", 500)
        self.burn_in_steps = self.config.get("burn_in_steps", 100)
        
        # Verification settings
        self.verify_frequency = self.config.get("verify_frequency", 0.1)  # 10% of steps
        self.verify_energy = self.config.get("verify_energy", False)
        
        # Diagnostics
        self.metrics = {
            "energy_history": [],
            "acceptance_rates": [],
            "computation_times": [],
            "flip_stats": {"proposed": 0, "accepted": 0, "rejected": 0},
            "energy_drift_history": [],
            "delta_energy_history": []
        }
    
    def initialize_energy(self, tiling_data: Dict) -> None:
        """Compute initial total energy with fresh computation"""
        self.current_energy = compute_total_energy_fresh(self.energy_model, tiling_data)
        self.metrics["energy_history"].append(self.current_energy)
    
    def _compute_region_energy_fresh(self, tile_ids: List[int], tiling_data: Dict, 
                                   extra_ring: int = 1) -> float:
        """
        Compute total energy of region with fresh computation
        Wipes region + extra_ring to prevent neighbor contamination
        """
        # Get region to wipe (region + extra ring)
           # Get region to wipe (region + extra ring)
        wipe_region = get_k_ring_neighborhood(tile_ids, tiling_data, k=extra_ring)
        
        # Wipe energy fields in wipe_region
        for tile_id in wipe_region:
            tile = tiling_data["tiles"][tile_id]
            tile.pop("local_energy", None)
            tile.pop("vertex_class", None)
        
        # Clear caches
        clear_all_caches(self.energy_model)
        
        # FIX: Compute fresh energy for ALL tiles in the wiped region
        energy = 0.0
        for tile_id in wipe_region:  # CHANGED FROM tile_ids TO wipe_region
            tile = tiling_data["tiles"][tile_id]
            if not tile.get("removed", False):
                energy += self.energy_model.compute_local_energy(tile_id, tiling_data)
        
        return energy
    
    def _verify_energy_consistency(self, tiling_data: Dict, message: str = "") -> float:
        """
        Verify current_energy matches recomputed total energy
        This is the CORRECT global verification
        """
        actual_energy = compute_total_energy_fresh(self.energy_model, tiling_data)
        drift = abs(actual_energy - self.current_energy)
        
        if drift > 0.001:
            print(f"⚠️  ENERGY DRIFT {message}: {drift:.6f} "
                  f"(MC={self.current_energy:.6f}, actual={actual_energy:.6f})")
        
        self.metrics["energy_drift_history"].append(drift)
        return drift
    
    # In src/simulation/mc_engine.py - Updated run_step method
    def run_step(self, tiling_data: Dict, debug_mode: bool = False) -> Tuple[bool, float]:
        """Single MC step with verified energy consistency"""
        step_start = time.time()
        self.metrics["flip_stats"]["proposed"] += 1
        
        # Find flippable clusters
        flippable_clusters = self.flip_engine.find_flippable_hexagons(tiling_data)
        if not flippable_clusters:
            self.metrics["computation_times"].append(time.time() - step_start)
            return False, 0.0
        
        cluster_ids = random.choice(flippable_clusters)
        
        # Get k-ring neighborhood for energy calculation
        energy_region = get_k_ring_neighborhood(
            cluster_ids, tiling_data, k=self.neighborhood_radius
        )
        
        # Capture state for undo
        undo_info = self.flip_engine.capture_state(cluster_ids, tiling_data)
        
        # Compute pre-flip energy FRESH (with extra ring to prevent contamination)
        energy_before = self._compute_region_energy_fresh(
            list(energy_region), tiling_data, extra_ring=1
        )
        
        # Apply flip
        success = self.flip_engine.apply_flip(cluster_ids, tiling_data)
        if not success:
            self.flip_engine.restore_state(undo_info, tiling_data)
            self.metrics["flip_stats"]["rejected"] += 1
            self.metrics["computation_times"].append(time.time() - step_start)
            return False, 0.0
        
        # Compute post-flip energy FRESH
        energy_after = self._compute_region_energy_fresh(
            list(energy_region), tiling_data, extra_ring=1
        )
        delta_energy = energy_after - energy_before
        
        # Metropolis acceptance
        accepted = self._metropolis_accept(delta_energy)
        
        if accepted:
            # Update global energy
            self.current_energy += delta_energy
            self.metrics["flip_stats"]["accepted"] += 1
            
            # VERIFICATION: In debug mode, verify every accepted step
            # In normal mode, use random verification
            if debug_mode:
                # Debug mode: verify EVERY accepted move
                drift = self._verify_energy_consistency(
                    tiling_data, 
                    f"after accepted flip {len(self.metrics['energy_history'])}"
                )
            elif self.verify_energy and random.random() < self.verify_frequency:
                # Normal mode: random verification
                drift = self._verify_energy_consistency(tiling_data)
        else:
            # Reject: restore state
            self.flip_engine.restore_state(undo_info, tiling_data)
            # Also wipe and recompute energy for consistency
            self._compute_region_energy_fresh(list(energy_region), tiling_data, extra_ring=1)
            self.metrics["flip_stats"]["rejected"] += 1
        
        # Record metrics
        self.metrics["energy_history"].append(self.current_energy)
        self.metrics["delta_energy_history"].append(delta_energy)
        self.metrics["computation_times"].append(time.time() - step_start)
        
        return accepted, delta_energy
    
    # Add this method to mc_engine.py for debug validation
    def run_debug_validation(self, tiling_data: Dict, steps: int = 200) -> Dict:
        """
        Run MC with full verification for debugging
        """
        print(f"🔍 Running debug validation for {steps} steps...")
        
        # Reset metrics for clean run
        self.metrics["energy_drift_history"] = []
        
        # Run with debug mode enabled
        stats = self.run_sweep(tiling_data, steps=steps, debug_mode=True)
        
        # Analyze drift
        drift_history = self.metrics["energy_drift_history"]
        if drift_history:
            max_drift = max(drift_history)
            mean_drift = np.mean(drift_history)
            print(f"📊 Debug validation results:")
            print(f"  Max drift: {max_drift:.6f}")
            print(f"  Mean drift: {mean_drift:.6f}")
            print(f"  Steps with drift > 0.001: {sum(1 for d in drift_history if d > 0.001)}")
            
            if max_drift > 0.001:
                print("⚠️  WARNING: Significant drift detected!")
            else:
                print("✅ SUCCESS: Energy consistency validated!")
        
        return stats
        
    def run_sweep(self, tiling_data: Dict, steps: Optional[int] = None, 
                  debug_mode: bool = False) -> Dict:
        """Run multiple MC steps with verification"""
        if steps is None:
            steps = self.base_steps
        
        # Initial verification if debug mode
        if debug_mode:
            drift = self._verify_energy_consistency(tiling_data, "initial")
            if drift > 0.01:
                print(f"❌ Large initial drift: {drift:.6f}")
        
        acceptance_count = 0
        delta_energies = []
        
        # Run steps
        for step in range(steps):
            accepted, delta = self.run_step(tiling_data, debug_mode=debug_mode)
            if accepted:
                acceptance_count += 1
                delta_energies.append(delta)
        
        # Final verification if debug mode
        if debug_mode:
            drift = self._verify_energy_consistency(tiling_data, "final")
        
        # Calculate statistics
        final_rate = acceptance_count / steps if steps > 0 else 0.0
        
        stats = {
            "steps": steps,
            "accepted": acceptance_count,
            "acceptance_rate": final_rate,
            "final_energy": self.current_energy,
            "delta_mean": 0.0,
            "delta_std": 0.0,
            "positive_ratio": 0.0,
            "max_drift": max(self.metrics["energy_drift_history"]) if self.metrics["energy_drift_history"] else 0.0
        }
        
        if delta_energies:
            delta_arr = np.array(delta_energies)
            stats["delta_mean"] = float(np.mean(delta_arr))
            stats["delta_std"] = float(np.std(delta_arr)) if len(delta_arr) > 1 else 0.0
            stats["positive_ratio"] = float(np.sum(delta_arr > 0) / len(delta_arr))
        
        print(f"✅ MC sweep: {acceptance_count}/{steps} accepted ({final_rate:.1%}), "
              f"max drift: {stats['max_drift']:.6f}")
        
        return stats
    
    def _metropolis_accept(self, delta_energy: float) -> bool:
        """Standard Metropolis criterion"""
        if delta_energy <= 0:
            return True
        return random.random() < math.exp(-delta_energy / self.temperature)
    
    def get_diagnostics(self) -> Dict[str, Any]:
        """Return comprehensive diagnostics"""
        if not self.metrics["energy_history"]:
            return {}
        
        proposed = max(1, self.metrics["flip_stats"]["proposed"])
        
        return {
            "temperature": self.temperature,
            "final_energy": self.current_energy,
            "acceptance_rate": self.metrics["flip_stats"]["accepted"] / proposed,
            "flip_statistics": self.metrics["flip_stats"],
            "energy_drift": {
                "max": max(self.metrics["energy_drift_history"]) if self.metrics["energy_drift_history"] else 0.0,
                "mean": np.mean(self.metrics["energy_drift_history"]) if self.metrics["energy_drift_history"] else 0.0
            },
            "config": {
                "neighborhood_radius": self.neighborhood_radius,
                "base_steps": self.base_steps,
                "burn_in_steps": self.burn_in_steps,
                "verify_frequency": self.verify_frequency
            }
        }