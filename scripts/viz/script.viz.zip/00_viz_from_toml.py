"""Run viz generation jobs from configs/publication_plots.toml.

Usage:
    python scripts/viz/00_viz_from_toml.py

Jobs are read from:
    [viz_jobs]
    enabled = true
    [[viz_jobs.jobs]]

Each job supports:
- kind = "state" | "compare" | "storyboard" | "movie" | "spatial"
- outdir = ... (optional)

Example job snip (put in configs/publication_plots.toml):

[viz_jobs]
enabled = true

defect_threshold = 1.5
energy_percentile = [5,95]
strain_percentile = [5,95]

[[viz_jobs.jobs]]
kind = "state"
input = "data/processed/penrose_tiling_energy_initialized.json"
plots = ["matrix_2x2", "grid_3x3", "diffraction", "vertex_dist", "strain_map"]
outdir = "data/viz/demo"

"""

from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))



from src.viz.config import load_publication_config, get_viz_jobs
from src.viz.io import load_tiling_state
from src.viz.static_plots import (
    plot_physics_matrix,
    plot_publication_grid_3x3,
    plot_diffraction_pattern,
    plot_vertex_distribution,
)
from src.viz.compare_plots import plot_pair, plot_triptych, plot_change_panel
from src.viz.strain_plots import plot_strain_energy_map
from src.viz.movie import make_storyboard, make_movie
from src.viz.spatial_plots import compute_spatial_bin_stats, plot_defect_density_by_distance


def main() -> int:
    cfg = load_publication_config()
    viz = cfg.get("viz_jobs", {})
    if not viz.get("enabled", False):
        print("viz_jobs.enabled is false -> nothing to run")
        return 0

    jobs = get_viz_jobs(cfg)
    if not jobs:
        print("No viz jobs found under [viz_jobs]")
        return 0

    for j in jobs:
        kind = str(j.get("kind", "")).strip().lower()
        outdir = j.get("outdir")

        print("\n============================================================")
        print(f"VIZ JOB: kind={kind}  outdir={outdir}")
        print("============================================================")

        if kind == "state":
            inp = j.get("input")
            if not inp:
                print("  ⚠️  Missing job.input")
                continue
            state = load_tiling_state(inp)
            plots = j.get("plots", ["matrix_2x2"])

            if "matrix_2x2" in plots:
                plot_physics_matrix(state, outdir=outdir, cfg=cfg)
            if "grid_3x3" in plots:
                plot_publication_grid_3x3(state, outdir=outdir, cfg=cfg)
            if "diffraction" in plots:
                plot_diffraction_pattern(state, outdir=outdir, cfg=cfg)
            if "vertex_dist" in plots:
                plot_vertex_distribution(state, outdir=outdir, cfg=cfg)
            if "strain_map" in plots:
                plot_strain_energy_map(state, outdir=outdir, cfg=cfg)

        elif kind == "compare":
            baseline = j.get("baseline")
            damaged = j.get("damaged")
            healed = j.get("healed") or j.get("current")
            if not baseline or not healed:
                print("  ⚠️  Need job.baseline and job.healed (or job.current)")
                continue
            b = load_tiling_state(baseline)
            h = load_tiling_state(healed)
            view = j.get("view", "energy")

            if damaged:
                d = load_tiling_state(damaged)
                plot_triptych(b, d, h, view=view, outdir=outdir, cfg=cfg)
            else:
                plot_pair(b, h, view=view, outdir=outdir, cfg=cfg)

            # Always produce a change panel baseline->healed
            plot_change_panel(b, h, outdir=outdir, cfg=cfg)

        elif kind == "storyboard":
            snapdir = j.get("snapshot_dir")
            if not snapdir:
                print("  ⚠️  Need job.snapshot_dir")
                continue
            view = j.get("view", "strain")
            n_frames = int(j.get("n_frames", 12))
            ncols = int(j.get("ncols", 4))
            make_storyboard(snapdir, view=view, n_frames=n_frames, ncols=ncols, outdir=outdir, cfg=cfg)

        elif kind == "movie":
            snapdir = j.get("snapshot_dir")
            if not snapdir:
                print("  ⚠️  Need job.snapshot_dir")
                continue
            view = j.get("view", "strain")
            fps = int(j.get("fps", 12))
            make_movie(snapdir, view=view, fps=fps, outdir=outdir, cfg=cfg)

        elif kind == "spatial":
            inp = j.get("input")
            if not inp:
                print("  ⚠️  Missing job.input")
                continue
            bin_edges = j.get("bin_edges", [0, 2, 4, 6, 8, 10])
            defect_threshold = float(j.get("defect_threshold", viz.get("defect_threshold", 1.5)))
            treat_immobile_as_fixed = bool(j.get("treat_immobile_as_fixed", viz.get("treat_immobile_as_fixed", False)))

            state = load_tiling_state(inp)
            snap = compute_spatial_bin_stats(
                state,
                bin_edges=bin_edges,
                defect_threshold=defect_threshold,
                treat_immobile_as_fixed=treat_immobile_as_fixed,
            )
            plot_defect_density_by_distance(snap, outdir=outdir, cfg=cfg)

        else:
            print(f"  ⚠️  Unknown kind: {kind}")

    print("\n✅ Viz jobs complete")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
