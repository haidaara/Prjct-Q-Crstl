from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#!/usr/bin/env python3
"""Compare baseline/damaged/healed (or baseline/healed) states.

Examples:
  # Baseline vs Healed
  python scripts/viz/02_viz_compare.py \
    --baseline data/processed/penrose_tiling_energy_initialized.json \
    --healed data/experiments/healing/healing_base_run_001.json \
    --view energy --outdir data/viz/compare

  # Baseline vs Damaged vs Healed
  python scripts/viz/02_viz_compare.py \
    --baseline ... --damaged ... --healed ... \
    --view strain --outdir data/viz/compare

This script produces:
- Pair or triptych panel (depends on whether --damaged is provided)
- Change panel (baseline->healed)
- Optional drift series (baseline->damaged/healed)
"""

import argparse
import sys

project_root = Path(__file__).resolve().parents[2]
sys.path.append(str(project_root))

from src.viz.config import load_publication_config
from src.viz.io import load_tiling_state
from src.viz.compare_plots import plot_pair, plot_triptych, plot_change_panel, plot_phason_drift_series


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--healed", required=True, help="Current/healed state JSON")
    ap.add_argument("--damaged", default=None, help="Optional damaged state JSON")
    ap.add_argument("--view", default="energy", help="geometry|energy|defects|class|growth|strain|change")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--drift", action="store_true", help="Also plot drift bar chart")
    args = ap.parse_args()

    cfg = load_publication_config(args.config)

    b = load_tiling_state(args.baseline)
    h = load_tiling_state(args.healed)

    if args.damaged:
        d = load_tiling_state(args.damaged)
        plot_triptych(b, d, h, view=args.view, outdir=args.outdir, cfg=cfg)
        if args.drift:
            plot_phason_drift_series(b, [("damaged", d), ("healed", h)], outdir=args.outdir, cfg=cfg)
    else:
        plot_pair(b, h, view=args.view, outdir=args.outdir, cfg=cfg)
        if args.drift:
            plot_phason_drift_series(b, [("healed", h)], outdir=args.outdir, cfg=cfg)

    plot_change_panel(b, h, outdir=args.outdir, cfg=cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
