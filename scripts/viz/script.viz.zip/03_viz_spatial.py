from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#!/usr/bin/env python3
"""Spatial (distance-to-obstacle) profiles from a *state* JSON.

This is meant for the next phase: statistical analysis around obstacles.

Example:
  python scripts/viz/03_viz_spatial.py \
    --input data/experiments/healing/healing_base_run_001.json \
    --outdir data/viz/spatial \
    --bin_edges 0,1,2,3,4,5,6,8,10

Outputs:
  - defect_density_by_distance (mean defect fraction per radial bin)
"""

import argparse
import sys

project_root = Path(__file__).resolve().parents[2]
sys.path.append(str(project_root))

from src.viz.config import load_publication_config
from src.viz.io import load_tiling_state
from src.viz.spatial_plots import compute_spatial_bin_stats, plot_defect_density_by_distance


def _csv_floats(s: str) -> list[float]:
    return [float(x.strip()) for x in (s or "").split(",") if x.strip()]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--bin_edges", default="0,2,4,6,8,10,12")
    ap.add_argument("--defect_threshold", default=None, help="Override threshold")
    ap.add_argument("--treat_immobile_as_fixed", action="store_true")
    args = ap.parse_args()

    cfg = load_publication_config(args.config)
    viz = cfg.get("viz_jobs", {})

    state = load_tiling_state(args.input)

    bin_edges = _csv_floats(args.bin_edges)
    defect_threshold = float(args.defect_threshold) if args.defect_threshold is not None else float(viz.get("defect_threshold", 1.5))

    snap = compute_spatial_bin_stats(
        state,
        bin_edges=bin_edges,
        defect_threshold=defect_threshold,
        treat_immobile_as_fixed=bool(args.treat_immobile_as_fixed),
    )
    plot_defect_density_by_distance(snap, outdir=args.outdir, cfg=cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
