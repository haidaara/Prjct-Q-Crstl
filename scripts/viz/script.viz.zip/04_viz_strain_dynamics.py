from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#!/usr/bin/env python3
"""Phason strain *dynamics* from a directory of snapshots.

Assumes each snapshot JSON contains per-tile ``phason_energy`` and optionally ``local_energy``.

Example:
  python scripts/viz/04_viz_strain_dynamics.py \
    --snapshot_dir data/experiments/healing/run_021/snapshots \
    --outdir data/viz/run_021

This script generates:
  - phason strain series (mean/max vs step)
  - optional correlation: defects vs mean strain
  - optional storyboard / movie frames (use --storyboard)
"""

import argparse
import sys

project_root = Path(__file__).resolve().parents[2]
sys.path.append(str(project_root))

from src.viz.config import load_publication_config
from src.viz.io import list_snapshots, load_tiling_state, iter_tiles
from src.viz.panels import get_obstacle_mask
from src.viz.strain_plots import compute_strain_series_from_snapshots, plot_strain_series, plot_strain_vs_defects
from src.viz.movie import make_storyboard


def _defect_count(state, *, defect_threshold: float, treat_immobile_as_fixed: bool = False) -> int:
    obs = get_obstacle_mask(state, treat_immobile_as_fixed=treat_immobile_as_fixed)
    n = 0
    for tid, t in iter_tiles(state):
        if obs.get(tid) is not None:
            continue
        if float(t.get("local_energy", 0.0) or 0.0) >= defect_threshold:
            n += 1
    return n


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot_dir", required=True)
    ap.add_argument("--pattern", default="*.json")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--defect_threshold", default=None)
    ap.add_argument("--treat_immobile_as_fixed", action="store_true")
    ap.add_argument("--with_defect_corr", action="store_true")
    ap.add_argument("--storyboard", action="store_true")
    ap.add_argument("--n_frames", default=12, type=int)
    ap.add_argument("--ncols", default=4, type=int)
    ap.add_argument("--view", default="strain", help="view for storyboard")
    args = ap.parse_args()

    cfg = load_publication_config(args.config)
    viz = cfg.get("viz_jobs", {})

    snap_paths = list_snapshots(args.snapshot_dir, pattern=args.pattern)
    if not snap_paths:
        print(f"No snapshots found in {args.snapshot_dir}")
        return 2

    series = compute_strain_series_from_snapshots(snap_paths)
    plot_strain_series(series, outdir=args.outdir, cfg=cfg)

    if args.with_defect_corr:
        defect_threshold = float(args.defect_threshold) if args.defect_threshold is not None else float(viz.get("defect_threshold", 1.5))
        treat = bool(args.treat_immobile_as_fixed)
        defect_counts = []
        for p in snap_paths:
            st = load_tiling_state(p)
            defect_counts.append(_defect_count(st, defect_threshold=defect_threshold, treat_immobile_as_fixed=treat))
        plot_strain_vs_defects(series, defect_counts, outdir=args.outdir, cfg=cfg)

    if args.storyboard:
        make_storyboard(args.snapshot_dir, view=args.view, n_frames=args.n_frames, ncols=args.ncols, outdir=args.outdir, cfg=cfg)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
