from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#!/usr/bin/env python3
"""Quick viz for a *single* tiling state JSON.

Example:
  python scripts/viz/01_viz_state.py \
    --input data/processed/penrose_tiling_energy_initialized.json \
    --outdir data/viz/demo \
    --plots matrix_2x2,grid_3x3,diffraction,vertex_dist,radial_defects,strain_map,strain_hist

Plot names:
  - matrix_2x2
  - grid_3x3
  - diffraction
  - vertex_dist
  - radial_defects
  - strain_map
  - strain_hist
  - strain_vs_distance
"""

import argparse
import sys

# Add project root so "src" imports work when you run from repo root.
project_root = Path(__file__).resolve().parents[2]
sys.path.append(str(project_root))

from src.viz.config import load_publication_config
from src.viz.io import load_tiling_state
from src.viz.static_plots import (
    plot_physics_matrix,
    plot_publication_grid_3x3,
    plot_diffraction_pattern,
    plot_vertex_distribution,
    plot_radial_defect_density,
)
from src.viz.strain_plots import (
    plot_strain_energy_map,
    plot_strain_histogram,
    plot_strain_vs_distance,
)


def _csv_list(s: str) -> list[str]:
    return [x.strip() for x in (s or "").split(",") if x.strip()]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Path to a state JSON containing tiles")
    ap.add_argument("--outdir", default=None, help="Output directory (optional)")
    ap.add_argument("--config", default=None, help="Path to publication_plots.toml (optional)")
    ap.add_argument(
        "--plots",
        default="matrix_2x2",
        help="Comma-separated plot names",
    )
    ap.add_argument(
        "--bin_edges",
        default="0,2,4,6,8,10,12",
        help="Bin edges for strain_vs_distance (comma-separated)",
    )
    args = ap.parse_args()

    cfg = load_publication_config(args.config)
    state = load_tiling_state(args.input)
    plots = set(_csv_list(args.plots))

    if "matrix_2x2" in plots:
        plot_physics_matrix(state, outdir=args.outdir, cfg=cfg)
    if "grid_3x3" in plots:
        plot_publication_grid_3x3(state, outdir=args.outdir, cfg=cfg)
    if "diffraction" in plots:
        plot_diffraction_pattern(state, outdir=args.outdir, cfg=cfg)
    if "vertex_dist" in plots:
        plot_vertex_distribution(state, outdir=args.outdir, cfg=cfg)
    if "radial_defects" in plots:
        plot_radial_defect_density(state, outdir=args.outdir, cfg=cfg)

    # Phason strain (publication-focused)
    if "strain_map" in plots:
        plot_strain_energy_map(state, outdir=args.outdir, cfg=cfg)
    if "strain_hist" in plots:
        plot_strain_histogram(state, outdir=args.outdir, cfg=cfg)
    if "strain_vs_distance" in plots:
        edges = [float(x) for x in _csv_list(args.bin_edges)]
        plot_strain_vs_distance(state, bin_edges=edges, outdir=args.outdir, cfg=cfg)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
