from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#!/usr/bin/env python3
"""Create a movie from a snapshot directory.

Example:
  python scripts/viz/05_viz_movie.py \
    --snapshot_dir data/experiments/healing/run_021/snapshots \
    --view strain --fps 12 --outdir data/viz/run_021

Requires imageio.
"""

import argparse
import sys

project_root = Path(__file__).resolve().parents[2]
sys.path.append(str(project_root))

from src.viz.config import load_publication_config
from src.viz.movie import make_movie


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot_dir", required=True)
    ap.add_argument("--view", default="strain")
    ap.add_argument("--fps", default=12, type=int)
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    cfg = load_publication_config(args.config)
    make_movie(args.snapshot_dir, view=args.view, fps=args.fps, outdir=args.outdir, cfg=cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
