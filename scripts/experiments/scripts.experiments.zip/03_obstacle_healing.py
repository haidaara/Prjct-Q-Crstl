#!/usr/bin/env python3
# scripts/experiments/03_obstacle_healing.py
"""Run obstacle healing (damage → anneal) and write snapshots + run_metrics.json.

Default usage:
  python scripts/experiments/03_obstacle_healing.py --config configs/obstacle_healing.toml

Optional overrides:
  python scripts/experiments/03_obstacle_healing.py --config configs/obstacle_healing.toml \
    --input data/pores/pores_density_0.05.json \
    --out data/experiments/healing/obstacle_healing_run_001
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List, Tuple

import sys

# Ensure project root is on PYTHONPATH so `import src...` works
ROOT = Path(__file__).resolve().parents[2]  # .../quasi-phason
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


try:
    import tomllib  # py3.11+
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore

from src.energy.widom_inspired_energy import WidomInspiredEnergy, EnergyParameters
from src.simulation.flip_engine import FlipEngine
from src.simulation.mc_engine import MonteCarloEngine

from src.obstacle_healing.experiment import ObstacleHealingExperiment


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/obstacle_healing.toml", help="TOML config for obstacle healing")
    p.add_argument("--input", default=None, help="Override run.input (tiling JSON path)")
    p.add_argument("--out", default=None, help="Override run.output_dir")
    p.add_argument("--skip-damage", action="store_true", help="Disable damage phase (debug)")
    return p.parse_args()


def load_toml(path: str) -> Dict[str, Any]:
    with open(path, "rb") as f:
        return tomllib.load(f)


def _get_schedule(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    anneal = cfg.get("anneal", {}) or {}
    schedule = anneal.get("schedule") or []
    if not schedule:
        # Safe default
        schedule = [
            {"T": 5.0, "steps": 100, "name": "T5.0"},
            {"T": 2.5, "steps": 200, "name": "T2.5"},
            {"T": 1.2, "steps": 200, "name": "T1.2"},
            {"T": 0.6, "steps": 200, "name": "T0.6"},
            {"T": 0.3, "steps": 200, "name": "T0.3"},
            {"T": 0.15, "steps": 200, "name": "T0.15"},
            {"T": 0.1, "steps": 800, "name": "T0.1"},
        ]
    out: List[Dict[str, Any]] = []
    for i, st in enumerate(schedule):
        T = float(st.get("T", st.get("temperature", 0.0)))
        steps = int(st.get("steps", 0))
        name = str(st.get("name") or f"stage_{i+1}")
        out.append({"T": T, "steps": steps, "name": name})
    return out


def main() -> None:
    args = parse_args()
    cfg = load_toml(args.config)

    run = cfg.get("run", {}) or {}
    logging_cfg = cfg.get("logging", {}) or {}
    region_cfg = cfg.get("region", {}) or {}
    defects_cfg = cfg.get("defects", {}) or {}
    damage_cfg = cfg.get("damage", {}) or {}
    anneal_cfg = cfg.get("anneal", {}) or {}

    input_path = str(args.input or run.get("input") or "data/processed/penrose_tiling_energy_initialized.json")
    output_dir = str(args.out or run.get("output_dir") or "data/experiments/healing/obstacle_healing_run_001")
    seed = int(run.get("seed", 0))

    schedule = _get_schedule(cfg)

    # Engines (use defaults unless explicitly overridden later)
    energy_model = WidomInspiredEnergy(EnergyParameters())
    flip_engine = FlipEngine(energy_model.classifier, energy_model)

    # MC engine verbosity kept low; experiment handles logging
    initial_T = float(schedule[0]["T"]) if schedule else 0.3
    mc_config = {
        "verbosity": 1,
        "verify_energy": False,  # we compute/report drift in experiment logs
        "trace_every": 50,
    }
    mc_engine = MonteCarloEngine(temperature=initial_T, energy_model=energy_model, flip_engine=flip_engine, config=mc_config)

    exp = ObstacleHealingExperiment(
        flip_engine=flip_engine,
        mc_engine=mc_engine,
        energy_model=energy_model,
        input_path=input_path,
        output_dir=output_dir,
        # seed=seed,
        # region
        annulus_inner_delta=float(region_cfg.get("annulus_inner_delta", 2.0)),
        annulus_outer_delta=float(region_cfg.get("annulus_outer_delta", 8.0)),
        fixed_k=int(region_cfg.get("fixed_k", 3)),
        # defects
        defect_threshold=float(defects_cfg.get("threshold", 1.5)),
        # damage
        enable_damage=bool(damage_cfg.get("enabled", True)) and (not args.skip_damage),
        target_defects=int(damage_cfg.get("target_defects", 15)),
        max_defect_attempts=int(damage_cfg.get("max_attempts", 5000)),
        refresh_k_ring=int(damage_cfg.get("refresh_k_ring", 1)),
        # anneal/record
        metrics_every=int(anneal_cfg.get("metrics_every_steps", 10)),
        snapshot_every=int(anneal_cfg.get("snapshot_every_steps", 50)),
        snapshot_on_stage_end=bool(anneal_cfg.get("snapshot_on_stage_end", True)),
        compute_energy_drift=bool(anneal_cfg.get("compute_energy_drift", True)),
        # logging
        log_level=str(logging_cfg.get("level", "normal")),
        print_every=int(logging_cfg.get("print_every_steps", 50)),
        damage_progress_every=int(logging_cfg.get("damage_progress_every_attempts", 500)),
        config_path=str(args.config),
    )

    exp.run(schedule=schedule)


if __name__ == "__main__":
    main()
